import  Objects.*;
import crypto.*;

import com.alibaba.fastjson.JSON;

import javax.naming.Name;
import java.sql.*;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class AdminServer {

    static class ExeClientThread implements  Runnable{ //每一个用户对应一个可执行线程
        private Socket ClientSocket; //该用户对应的Socket类
        private String PublicKey;
        private String PrivateKey;

        ExeClientThread(Socket ClientSocket) throws Exception {
            this.ClientSocket=ClientSocket;
        }
        @Override
        public void run() {
            try {
                Map<String,String> KeyPair = RSA.generateKeyPair(); //生成公私钥对
                PublicKey=KeyPair.get("publicKey");
                PrivateKey=KeyPair.get("privateKey");
                PrintStream SendToClient = new PrintStream(ClientSocket.getOutputStream());
                //Socket.getOutputStream类：得到的是一个输出流，服务端的Socket对象上的getOutputStream方法得到的输出流其实就是发送给客户端的数据。
                Scanner ReceiveFromClient = new Scanner(ClientSocket.getInputStream());
                //client.getInputStream类：到一个输入流，服务端的Socket对象上的getInputStream方法得到输入流其实就是从客户端发回的数据。
                /*主要流程在这里*/
                if(ReceiveFromClient.hasNext()) {
                    String message = ReceiveFromClient.next(); //客户端发来的信息
                    System.out.println(message);
                    switch (message) {
                        case "login":{ // 登录
                            SendToClient.println(PublicKey); //向客户端返回服务器公钥
                            if(ReceiveFromClient.hasNext()) { // 等待用户发送id与password
                                String EncodedUserData = ReceiveFromClient.next();
                                String userData = RSA.decrypt(EncodedUserData,PrivateKey);
                                Id_passwd userIdPassword = JSON.parseObject(userData, Id_passwd.class); //将客户端传来的JSON转化为类
                                String id = userIdPassword.id;
                                String password = userIdPassword.password;
                                String md5PassWord = Digest.signMD5(password,"UTF-8"); // password的哈希值
                                int flag = 0;
                                // 连接数据库查询id和password的md5是否相等 TODO
                                Connection ConToSql=SQL.SQLConnector();
                                if (!ConToSql.isClosed()) {
                                    System.out.println("数据库连接成功\n");
                                }
                                String sql="SELECT passwd FROM manager_passwords WHERE id = ?";//定义查询语句
                                ConToSql.setAutoCommit(true);
                                PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                preparedStatement.setString(1,id);
                                ResultSet resultSet = preparedStatement.executeQuery();
                                while(resultSet.next()){
                                    String RealMD5 = resultSet.getString("passwd");
                                    if(RealMD5.equals(md5PassWord))
                                        flag=1;
                                }
                                // 返回私钥签名的结果sign
                                Login_res result = new Login_res();

                                if (flag == 1) result.login = "true&time=time";
                                else  result.login = "false&time=time";
                                result.sign = RSA.sign(result.login,PrivateKey);
                                String resultJson = JSON.toJSONString(result);// 将类转化为JSON
                                SendToClient.println(resultJson); // 结果返回给客户端
                                /*以下为关闭流*/
                                ConToSql.close();
                                preparedStatement.close();
                                resultSet.close();
                                SendToClient.close();
                                ReceiveFromClient.close();
                                ClientSocket.close();
                                return;
                            }
                            break;
                        }
                        case "register":{ // 注册
                            System.out.println(message);
                            SendToClient.println(PublicKey); //向客户端返回服务器公钥
                            System.out.println(PublicKey);
                            String id="";
                            String password = "";
                            String md5PassWord = "";
                            if(ReceiveFromClient.hasNext()) { // 等待用户发送id与password
                                // 解密
                                String EncodedUserData = ReceiveFromClient.next();
                                String userData = RSA.decrypt(EncodedUserData,PrivateKey);
                                System.out.println("得到新管理员的账号密码"+userData);
                                Id_passwd userIdPassword = JSON.parseObject(userData, Id_passwd.class); //将客户端传来的JSON转化为类
                                id = userIdPassword.id;
                                password = userIdPassword.password;
                                md5PassWord = Digest.signMD5(password,"UTF-8"); // password的哈希值
                            }
                            int flag = 0;
                            Random random = new Random(); // 定义随机类
                            int result = random.nextInt( 10 ); // 返回[0,10)集合中的整数，注意不包括10
                            result = result + 1;
                            // 连接数据库
                            Connection ConToSql=SQL.SQLConnector();
                            if (!ConToSql.isClosed()) {
                                System.out.println("数据库连接成功\n");
                            }
                            String sql="SELECT protection_question_text FROM protection_questions WHERE question_id = ?";//定义查询语句
                            ConToSql.setAutoCommit(true);
                            PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                            preparedStatement.setInt(1,result);
                            ResultSet resultSet = preparedStatement.executeQuery();
                            String question = "";
                            while(resultSet.next()) {
                                question = resultSet.getString("protection_question_text"); // 得到问题
                            }
                            System.out.println("问题"+result+":"+question);
                            SendToClient.println(question); // 问题返回给客户端
                            // 等待用户发送RSA(问题答案)
                            if(ReceiveFromClient.hasNext()) {
                                System.out.println("NICE");
                                String mAnswer = ReceiveFromClient.next();
                                System.out.println("mAnswer:"+mAnswer);
                                String answer =RSA.decrypt(mAnswer,PrivateKey); // 解密出回答哈希明文
                                System.out.println("用户回答:"+answer);
                                String md5answer = Digest.signMD5(answer,"UTF-8"); // md5的哈希值
                                // 此时连接数据库，将id、密码、问题号、问题答案的哈希值存入数据库 TODO
                                sql = "SELECT manager_id FROM managers WHERE manager_id = ?"; //首先
                                ConToSql.setAutoCommit(true);
                                preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                preparedStatement.setString(1,id);
                                resultSet = preparedStatement.executeQuery();
                                if(!resultSet.next()){ //数据库中没有相同的id才插入
                                    flag = 1;
                                    sql="INSERT INTO managers (manager_id) VALUES (?)"; //先插入users表
                                    preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                    preparedStatement.setString(1,id);
                                    preparedStatement.executeUpdate();
                                    String sql1 = "INSERT INTO manager_passwords (id,passwd,protection_question_id,protection_answer_hash) VALUES (?,?,?,?)";
                                    preparedStatement = ConToSql.prepareStatement(sql1); //执行查询结果并且返回结果集 ('"+id+"','"+md5PassWord+"',"+result+",'"+md5answer+"')"
                                    preparedStatement.setString(1,id);
                                    preparedStatement.setString(2,md5PassWord);
                                    preparedStatement.setInt(3,result);
                                    preparedStatement.setString(4, md5answer);
                                    preparedStatement.executeUpdate();
                                }
                                if(flag==0)
                                    SendToClient.println("NO");
                                else
                                    SendToClient.println("OK");
                                /*以下为关闭流*/
                                ConToSql.close();
                                preparedStatement.close();
                                resultSet.close();
                                SendToClient.close();
                                ReceiveFromClient.close();
                                ClientSocket.close();
                                return;
                            }
                            break;
                        }
                        case "forget":{ // 忘记密码/修改密码
                            System.out.println("iiii"+message);
                            SendToClient.println(PublicKey); //向客户端返回服务器公钥
                            String id = "";
                            if(ReceiveFromClient.hasNext()){
                                String Encoded_id = ReceiveFromClient.next();
                                id = RSA.decrypt(Encoded_id,PrivateKey);
                            }
                            Connection ConToSql=SQL.SQLConnector();
                            if (!ConToSql.isClosed()) {
                                System.out.println("数据库连接成功\n");
                            }
                            // 连接数据库，查询该id对应的是哪一个密保问题，得到其密保问题的编号
                            String sql="SELECT protection_question_id FROM manager_passwords WHERE id = ?";//定义查询语句
                            ConToSql.setAutoCommit(true);
                            PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                            preparedStatement.setString(1, id);
                            ResultSet resultSet = preparedStatement.executeQuery();
                            int question_id=0;
                            while(resultSet.next()) {
                                question_id = resultSet.getInt("protection_question_id");
                            }

                            //再查询密保问题正文，将其发还用户
                            String question = "";

                            sql="SELECT protection_question_text FROM protection_questions WHERE question_id = ?";//定义查询语句
                            preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                            preparedStatement.setInt(1,question_id);
                            resultSet = preparedStatement.executeQuery();
                            while(resultSet.next()) {
                                question = resultSet.getString("protection_question_text");
                            }
                            SendToClient.println(question); // 问题返回给客户端

                            // 等待用户发送RSA(问题答案)
                            String answer="";
                            if(ReceiveFromClient.hasNext()){
                                String EncodedAnswer = ReceiveFromClient.next();
                                answer = RSA.decrypt(EncodedAnswer,PrivateKey);
                                System.out.println(answer);
                            }
                            String RealAnswer = "";
                            // 验证问题答案的哈希与所存储的答案的哈希是否一致，如果一致，就返回给用户OK，如果不一致，返回NO，断开连接
                            sql = "SELECT protection_answer_hash FROM manager_passwords WHERE id = ?";
                            preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                            preparedStatement.setString(1,id);
                            resultSet = preparedStatement.executeQuery();
                            while(resultSet.next()) {
                                RealAnswer = resultSet.getString("protection_answer_hash");
                            }
                            String HashAnswer = Digest.signMD5(answer,"UTF-8");
                            if(!RealAnswer.equals(HashAnswer)){ //不符合
                                SendToClient.println("NO");
                                ConToSql.close();
                                preparedStatement.close();
                                resultSet.close();
                                SendToClient.close();
                                ReceiveFromClient.close();
                                ClientSocket.close();
                                return;
                            }else{
                                SendToClient.println("OK");
                                // OK后继续等待用户返回密码RSA(密码明文)
                                if(ReceiveFromClient.hasNext()){
                                    String EndocedPasswd = ReceiveFromClient.next();
                                    String Passwd = RSA.decrypt(EndocedPasswd,PrivateKey);
                                    String HashPasswd = Digest.signMD5(Passwd,"UTF-8");
                                    String sql2 = "UPDATE manager_passwords SET passwd = ? WHERE id = ?";
                                    preparedStatement = ConToSql.prepareStatement(sql2); //执行查询结果并且返回结果集
                                    preparedStatement.setString(1,HashPasswd);
                                    preparedStatement.setString(2,id);
                                    preparedStatement.executeUpdate();
                                }
                            }
                            ConToSql.close();
                            preparedStatement.close();
                            resultSet.close();
                            SendToClient.close();
                            ReceiveFromClient.close();
                            ClientSocket.close();
                            //return;
                            // 将其哈希值存入数据库中，断开连接
                            break;
                        }
                        case "select":{ //
                            // 生成公私钥对，发还公钥
                            SendToClient.println(PublicKey); //向客户端返回服务器公钥
                            String region = "";
                            if(ReceiveFromClient.hasNext()){
                                region = ReceiveFromClient.next();
                            }
                            Connection ConToSql=SQL.SQLConnector();
                            if (!ConToSql.isClosed()) {
                                System.out.println("数据库连接成功\n");
                            }
                            // 连接数据库，查询该id对应的是哪一个密保问题，得到其密保问题的编号
                            String sql="SELECT user_name FROM users WHERE user_region = ? AND user_state = 1";//定义查询语句
                            ConToSql.setAutoCommit(true);
                            PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                            preparedStatement.setString(1,region);
                            ResultSet resultSet = preparedStatement.executeQuery();
                            Names names = new Names();
                            while(resultSet.next()){
                                String new_name = resultSet.getString("user_name");
                                names.names.add(new_name);
                            }
                            String NamesJSON=JSON.toJSONString(names);
                            Infecteds infecteds = new Infecteds();
                            infecteds.Infecteds=NamesJSON;
                            infecteds.sign = RSA.sign(infecteds.Infecteds,PrivateKey);
                            String InfectsJSON =JSON.toJSONString(infecteds);
                            SendToClient.println(InfectsJSON);
                            //接下来等待用户发来姓名
                            String name = "";
                            if(ReceiveFromClient.hasNext()){
                                name = ReceiveFromClient.next();
                            }
                            String sql3 = "SELECT user_name, user_sex, user_age, user_infected_date FROM users WHERE user_name=? AND user_region=?";
                            preparedStatement = ConToSql.prepareStatement(sql3); //执行查询结果并且返回结果集
                            preparedStatement.setString(1,name);
                            preparedStatement.setString(2, region);
                            resultSet = preparedStatement.executeQuery();
                            Infected_info infected_info = new Infected_info();
                            while(resultSet.next()){
                                infected_info.name = resultSet.getString("user_name");
                                infected_info.sex = resultSet.getString("user_sex");
                                infected_info.age = resultSet.getString("user_age");
                                infected_info.infected_time = resultSet.getString("user_infected_date");
                            }
                            String InfectedJSON = JSON.toJSONString(infected_info);
                            SendToClient.println(InfectedJSON);
                            ConToSql.close();
                            preparedStatement.close();
                            resultSet.close();
                            SendToClient.close();
                            ReceiveFromClient.close();
                            ClientSocket.close();
                            //return;
                            break;
                        }
                        case "update":{ // 提交修改有关信息
                            if(ReceiveFromClient.hasNext()){
                                String id =ReceiveFromClient.next();
                                Connection ConToSql=SQL.SQLConnector();
                                if (!ConToSql.isClosed()) {
                                    System.out.println("数据库连接成功\n");
                                }
                                // 连接数据库，查询该id对应的是哪一个密保问题，得到其密保问题的编号
                                String sql="UPDATE users SET user_state = 1 WHERE user_id = ?";//定义查询语句
                                ConToSql.setAutoCommit(true);
                                PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                preparedStatement.setString(1,id);
                                preparedStatement.executeUpdate();
                            }
                            // 生成公私钥对，发还公钥
                            // 继续等待用户发送：RSA({id:"xxx",name:"xxx",sex:"xxx",region:"xxx",birthday:"2001-12-17",password:"xxx"})
                            // 连接数据库验证密码正确性
                            // 验证正确性之后，连接数据库update修改对应的信息
                            break;
                        }
                        default:{
                            SendToClient.close();
                            ReceiveFromClient.close();
                            ClientSocket.close();
                            //return;
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void close(PreparedStatement pstmt) {
        if(pstmt != null){ //避免出现空指针异常
            try{
                pstmt.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("MainSever Start");
        try{
            ExecutorService executorService = Executors.newFixedThreadPool(100); //最多同时执行100线程
            ServerSocket serverSocket = new ServerSocket(8879);
            while(true){
                Socket client = serverSocket.accept(); //服务器开启请求监听，该语句将阻塞，直到有用户请求连接
                System.out.println("\nNew user:"+client.getInetAddress()+":"+client.getPort());
                client.setSoTimeout(10000);
                executorService.execute(new ExeClientThread(client)); //进入新的用户进程
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
