import Objects.Id_passwd;
import com.alibaba.fastjson.*;

public class JSONtest {
    public static void main(String[] args) {
        String id = "yzx";
        String password = "whoami";
        Id_passwd id_passwd = new Id_passwd();
        id_passwd.id=id;
        id_passwd.password=password;
        //----------将类转换为JSON----------
        String Json = JSON.toJSONString(id_passwd);
        System.out.println("Json为:"+Json);
        //----------将JSON转换为类----------
        Id_passwd FromJson = JSON.parseObject(Json,Id_passwd.class);
        System.out.println("id为:"+FromJson.id);
        System.out.println("password为:"+FromJson.password);
    }
}
