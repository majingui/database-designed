import  Objects.*;
import crypto.*;

import com.alibaba.fastjson.JSON;
import java.sql.*;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainServer { //大众服务端

    static class ExeClientThread implements  Runnable{ //每一个用户对应一个可执行线程
        private Socket ClientSocket; //该用户对应的Socket类
        private String PublicKey;
        private String PrivateKey;

        ExeClientThread(Socket ClientSocket) throws Exception {
            this.ClientSocket=ClientSocket;
        }
        @Override
        public void run() {
            try {
                Map<String,String> KeyPair = RSA.generateKeyPair(); //生成公私钥对
                PublicKey=KeyPair.get("publicKey");
                PrivateKey=KeyPair.get("privateKey");
                PrintStream SendToClient = new PrintStream(ClientSocket.getOutputStream());
                //Socket.getOutputStream类：得到的是一个输出流，服务端的Socket对象上的getOutputStream方法得到的输出流其实就是发送给客户端的数据。
                Scanner ReceiveFromClient = new Scanner(ClientSocket.getInputStream());
                //client.getInputStream类：到一个输入流，服务端的Socket对象上的getInputStream方法得到输入流其实就是从客户端发回的数据。
                /*主要流程在这里*/
                if(ReceiveFromClient.hasNext()) {
                    String message = ReceiveFromClient.next(); //客户端发来的信息
                    switch (message) {
                        case "login":{ // 登录
                            System.out.println(message);
                            SendToClient.println(PublicKey); //向客户端返回服务器公钥
                            if(ReceiveFromClient.hasNext()) { // 等待用户发送id与password
                                String EncodedUserData = ReceiveFromClient.next();
                                String userData = RSA.decrypt(EncodedUserData,PrivateKey);
                                Id_passwd userIdPassword = JSON.parseObject(userData, Id_passwd.class); //将客户端传来的JSON转化为类
                                String id = userIdPassword.id;
                                System.out.println("用户id:"+id);
                                String password = userIdPassword.password;
                                String md5PassWord = Digest.signMD5(password,"UTF-8"); // password的哈希值
                                int flag = 0;
                                // 连接数据库查询id和password的md5是否相等 TODO
                                Connection ConToSql=SQL.SQLConnector();
                                if (!ConToSql.isClosed()) {
                                    System.out.println("数据库连接成功\n");
                                }
                                String sql="SELECT passwd FROM user_passwords WHERE id = ?";//定义查询语句
                                ConToSql.setAutoCommit(true);
                                PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                preparedStatement.setString(1,id);
                                ResultSet resultSet = preparedStatement.executeQuery();
                                while(resultSet.next()){
                                    String RealMD5 = resultSet.getString("passwd");
                                    System.out.println("realMD5:"+RealMD5);
                                    System.out.println("inputMD5:"+md5PassWord);
                                    if(RealMD5.equals(md5PassWord))
                                        flag=1;
                                }
                                // 返回私钥签名的结果sign
                                Login_res result = new Login_res();
                                if (flag == 1) result.login = "true&time=time";
                                else  result.login = "false&time=time";
                                result.sign = RSA.sign(result.login,PrivateKey);
                                String resultJson = JSON.toJSONString(result);// 将类转化为JSON
                                SendToClient.println(resultJson); // 结果返回给客户端
                                /*以下为关闭流*/
                                ConToSql.close();
                                preparedStatement.close();
                                resultSet.close();
                                SendToClient.close();
                                ReceiveFromClient.close();
                                ClientSocket.close();
                                return;
                            }
                            break;
                        }
                        case "register":{ // 注册
                            System.out.println(message);
                            SendToClient.println(PublicKey); //向客户端返回服务器公钥
                            if(ReceiveFromClient.hasNext()) { // 等待用户发送id与password
                                // 解密
                                String EncodedUserData = ReceiveFromClient.next();
                                String userData = RSA.decrypt(EncodedUserData,PrivateKey);
                                Id_passwd userIdPassword = JSON.parseObject(userData, Id_passwd.class); //将客户端传来的JSON转化为类
                                String id = userIdPassword.id;
                                System.out.println("用户id:"+id);
                                String password = userIdPassword.password;
                                String md5PassWord = Digest.signMD5(password,"UTF-8"); // password的哈希值
                                // 然后选择一个随机数（1~10）作为问题号，从密保问题表中取出一个问题，将问题发给用户 TODO
                                Random random = new Random(); // 定义随机类
                                int number = random.nextInt( 10 ); // 返回[0,10)集合中的整数，注意不包括10
                                number = number + 1;
                                // 连接数据库
                                Connection ConToSql=SQL.SQLConnector();
                                if (!ConToSql.isClosed()) {
                                    System.out.println("数据库连接成功\n");
                                }
                                String sql="SELECT protection_question_text FROM protection_questions WHERE question_id =?";//定义查询语句
                                ConToSql.setAutoCommit(true);
                                PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                preparedStatement.setInt(1,number);
                                ResultSet resultSet = preparedStatement.executeQuery();
                                String question = "";
                                while (resultSet.next()) {
                                    question = resultSet.getString("protection_question_text"); // 得到问题
                                }
                                System.out.println("所选择问题:"+question);
                                SendToClient.println(question); // 问题返回给客户端
                                // 等待用户发送RSA(问题答案)
                                if(ReceiveFromClient.hasNext()) {
                                    String mAnswer = ReceiveFromClient.next();
                                    String answer =RSA.decrypt(mAnswer,PrivateKey); // 解密出回答明文
                                    System.out.println("用户答案:"+answer);
                                    String md5answer = Digest.signMD5(answer,"UTF-8"); // password的哈希值
                                    // 将id、密码、问题号、问题答案的哈希值存入数据库 TODO
                                    String SELECT = "SELECT * FROM user_passwords WHERE id = ?"; // 查询用户id是否已经存在于数据库中
                                    preparedStatement = ConToSql.prepareStatement(SELECT); //执行查询结果并且返回结果集
                                    preparedStatement.setString(1,id);
                                    ResultSet resultSet_se = preparedStatement.executeQuery();
                                    int flag = 0;
                                    if (!resultSet_se.next()) {
                                        System.out.println("注册成功");
                                        flag = 1;
                                        sql="INSERT INTO users (user_id) VALUES (?)"; //先插入users表
                                        preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                        preparedStatement.setString(1,id);
                                        preparedStatement.executeUpdate();
                                        sql = "INSERT INTO user_passwords (id,passwd,protection_question_id,protection_answer_hash) VALUES (?,?,?,?)";
                                        preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                        preparedStatement.setString(1,id);
                                        preparedStatement.setString(2,md5PassWord);
                                        preparedStatement.setInt(3,number);
                                        preparedStatement.setString(4,md5answer);
                                        preparedStatement.executeUpdate();
                                    }
                                    // 返回注册成功的信息"OK"
                                    if (flag == 1) {
                                        SendToClient.println("OK"); // 结果返回给客户端
                                    } else {
                                        SendToClient.println("NO");
                                    }
                                    /*以下为关闭流*/
                                    ConToSql.close();
                                    preparedStatement.close();
                                    resultSet.close();
                                    SendToClient.close();
                                    ReceiveFromClient.close();
                                    ClientSocket.close();
                                    return;
                                }
                            }
                            break;
                        }
                        case "forget":{// 忘记密码/修改密码
                            System.out.println(message);
                            SendToClient.println(PublicKey); //向客户端返回服务器公钥
                            String id = "";
                            if(ReceiveFromClient.hasNext()){
                                String Encoded_id = ReceiveFromClient.next();
                                id = RSA.decrypt(Encoded_id,PrivateKey);
                            }
                            Connection ConToSql=SQL.SQLConnector();
                            if (!ConToSql.isClosed()) {
                                System.out.println("数据库连接成功\n");
                            }
                            // 连接数据库，查询该id对应的是哪一个密保问题，得到其密保问题的编号
                            String sql="SELECT protection_question_id FROM user_passwords WHERE id = ?";//定义查询语句
                            ConToSql.setAutoCommit(true);
                            PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                            preparedStatement.setString(1,id);
                            ResultSet resultSet = preparedStatement.executeQuery();
                            int question_id=0;
                            while(resultSet.next()) {
                                question_id = resultSet.getInt("protection_question_id");
                            }

                            //再查询密保问题正文，将其发还用户
                            String question = "";

                            sql="SELECT protection_question_text FROM protection_questions WHERE question_id = ?";//定义查询语句
                            preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                            preparedStatement.setInt(1,question_id);
                            resultSet = preparedStatement.executeQuery();
                            while(resultSet.next()) {
                                question = resultSet.getString("protection_question_text");
                            }
                            SendToClient.println(question); // 问题返回给客户端

                            // 等待用户发送RSA(问题答案)
                            String answer="";
                            if(ReceiveFromClient.hasNext()){
                                String EncodedAnswer = ReceiveFromClient.next();
                                answer = RSA.decrypt(EncodedAnswer,PrivateKey);
                            }
                            String HashAnswer = Digest.signMD5(answer,"UTF-8");
                            String RealAnswer = "";
                            // 验证问题答案的哈希与所存储的答案的哈希是否一致，如果一致，就返回给用户OK，如果不一致，返回NO，断开连接
                            sql = "SELECT protection_answer_hash FROM user_passwords WHERE id = ?";
                            preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                            preparedStatement.setString(1,id);
                            resultSet = preparedStatement.executeQuery();
                            while(resultSet.next()) {
                                RealAnswer = resultSet.getString("protection_answer_hash");
                            }
                            System.out.println("问题正确答案:"+RealAnswer);
                            System.out.println("用户提交答案:"+HashAnswer);
                            if(!RealAnswer.equals(HashAnswer)){ //不符合
                                System.out.println("回答错误");
                                SendToClient.println("NO");
                                ConToSql.close();
                                preparedStatement.close();
                                resultSet.close();
                                SendToClient.close();
                                ReceiveFromClient.close();
                                ClientSocket.close();
                                return;
                            }else{
                                SendToClient.println("OK");
                                System.out.println("回答正确");
                                // OK后继续等待用户返回密码RSA(密码明文)
                                if(ReceiveFromClient.hasNext()){
                                    String EndocedPasswd = ReceiveFromClient.next();
                                    String Passwd = RSA.decrypt(EndocedPasswd,PrivateKey);
                                    String HashPasswd = Digest.signMD5(Passwd,"UTF-8");
                                    String sql1 = "UPDATE user_passwords SET passwd = ? WHERE id = ?";
                                    preparedStatement = ConToSql.prepareStatement(sql1); //执行查询结果并且返回结果集
                                    preparedStatement.setString(1,HashPasswd);
                                    preparedStatement.setString(2,id);
                                    preparedStatement.executeUpdate();
                                }
                            }
                            ConToSql.close();
                            preparedStatement.close();
                            resultSet.close();
                            SendToClient.close();
                            ReceiveFromClient.close();
                            ClientSocket.close();
                            //return;
                            // 将其哈希值存入数据库中，断开连接
                            break;
                        }
                        case "select":{ // 查询身边是否有密接者
                            SendToClient.println(PublicKey); //向客户端返回服务器公钥
                            if (ReceiveFromClient.hasNext()) {
                                String EncodedId = ReceiveFromClient.next();
                                String userId = RSA.decrypt(EncodedId,PrivateKey); // 解密出用户id
                                Connection ConToSql=SQL.SQLConnector(); // 连接数据库
                                if (!ConToSql.isClosed()) {
                                    System.out.println("数据库连接成功\n");
                                }
                                String sql="SELECT region_infected_people FROM regions, users WHERE users.user_region = regions.region_name AND user_id = ?";//查询该id对应地区的阳性人数
                                ConToSql.setAutoCommit(true);
                                PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                preparedStatement.setString(1,userId);
                                ResultSet resultSet = preparedStatement.executeQuery();
                                while (resultSet.next()) {
                                    int infectedNum = resultSet.getInt("region_infected_people");
                                    SendToClient.println(infectedNum); // 将查询结果返回给客户端
                                }
                                /*以下为关闭流*/
                                ConToSql.close();
                                preparedStatement.close();
                                resultSet.close();
                                SendToClient.close();
                                ReceiveFromClient.close();
                                ClientSocket.close();
                                return;
                            }
                            break;
                        }
                        case "update":{ // 更新信息
                            System.out.println(message);
                            SendToClient.println(PublicKey); //向客户端返回服务器公钥
                            if (ReceiveFromClient.hasNext()) {
                                String EncodedUserData = ReceiveFromClient.next();
                                User_info userInfo = JSON.parseObject(RSA.decrypt(EncodedUserData,PrivateKey), User_info.class); //将客户端传来的JSON解密并转化为类
                                String userId = userInfo.id; // 用户ID
                                System.out.println("id"+userId);
                                String name = userInfo.name; // 用户姓名
                                System.out.println("name"+name);
                                int sex = userInfo.sex; // 用户性别
                                System.out.println("sex"+sex);
                                String region = userInfo.region; // 用户所在地区
                                System.out.println("region"+region);
                                String birthday = userInfo.birthday; // 用户生日
                                System.out.println("birthday"+birthday);
                                String password = userInfo.password; // 用户密码
                                System.out.println("password"+password);
                                String mPassWord = Digest.signMD5(password, "UTF-8"); // 用户密码哈希
                                Connection ConToSql=SQL.SQLConnector();
                                if (!ConToSql.isClosed()) {
                                    System.out.println("数据库连接成功\n");
                                }
                                int flag = 0;
                                String sql="SELECT passwd FROM user_passwords WHERE id = ?";//定义查询语句
                                ConToSql.setAutoCommit(true);
                                PreparedStatement preparedStatement = ConToSql.prepareStatement(sql); //执行查询结果并且返回结果集
                                preparedStatement.setString(1,userId);
                                ResultSet resultSet = preparedStatement.executeQuery();
                                System.out.println(123);
                                while(resultSet.next()){ // 判断用户密码的哈希值与数据库中存储的哈希值是否一致
                                    String RealMD5 = resultSet.getString("passwd");
                                    System.out.println("RealMD5:"+RealMD5);
                                    System.out.println("mPassWord:"+mPassWord);
                                    if(RealMD5.equals(mPassWord))
                                        flag=1;
                                }
                                if (flag == 0) {
                                    System.out.println("passwd error");
                                    SendToClient.println("NO"); // 如果密码不正确 向客户端返回NO
                                } else {
                                    System.out.println("passwd right");
                                    String UPDATE = "UPDATE users SET user_name=?, user_birthday= ?, user_sex= ?, user_region= ? WHERE user_id = ?"; // 更新语句
                                    ConToSql.setAutoCommit(true);
                                    preparedStatement = ConToSql.prepareStatement(UPDATE); //执行查询结果并且返回结果集
                                    preparedStatement.setString(1,name);
                                    preparedStatement.setString(2,birthday);
                                    preparedStatement.setInt(3,sex);
                                    preparedStatement.setString(4,region);
                                    preparedStatement.setString(5,userId);
                                    preparedStatement.executeUpdate();

                                    SendToClient.println("OK"); // 更新完成，向客户端回复OK
                                }
                                /*以下为关闭流*/
                                ConToSql.close();
                                preparedStatement.close();
                                resultSet.close();
                                SendToClient.close();
                                ReceiveFromClient.close();
                                ClientSocket.close();
                                return;
                            }
                            break;
                        }
                        default:{
                            SendToClient.close();
                            ReceiveFromClient.close();
                            ClientSocket.close();
                            //return;
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void close(PreparedStatement pstmt) {
        if(pstmt != null){ //避免出现空指针异常
            try{
                pstmt.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("MainSever Start");
        try{
            ExecutorService executorService = Executors.newFixedThreadPool(100); //最多同时执行100线程
            ServerSocket serverSocket = new ServerSocket(8899);
            while(true){
                Socket client = serverSocket.accept(); //服务器开启请求监听，该语句将阻塞，直到有用户请求连接
                System.out.println("\nNew user:"+client.getInetAddress()+":"+client.getPort());
                executorService.execute(new ExeClientThread(client)); //进入新的用户进程
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
