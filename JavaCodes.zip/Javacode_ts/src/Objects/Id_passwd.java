package Objects;

public class Id_passwd {
    public String id;
    public String password;
}
