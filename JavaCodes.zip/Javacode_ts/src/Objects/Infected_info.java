package Objects;

public class Infected_info { //存放感染者的信息
    public String name;
    public String sex;
    public String age;
    public String infected_time;
}
