package Objects;

import java.util.ArrayList;
import java.util.List;

public class Names {
    public List<String> names = new ArrayList<String>();
}
