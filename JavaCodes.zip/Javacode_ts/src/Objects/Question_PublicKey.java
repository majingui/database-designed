package Objects;

public class Question_PublicKey {
    public String question;
    public String publicKey;
}
