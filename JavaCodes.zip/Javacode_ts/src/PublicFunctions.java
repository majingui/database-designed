import Objects.*;
import com.alibaba.fastjson.JSON;
import crypto.RSA;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

public class PublicFunctions {
    public static boolean login(String id,String password) throws Exception {
        Socket socket = new Socket("103.46.128.53",48411);
        PrintStream printStream = new PrintStream(socket.getOutputStream());
        Scanner scanner = new Scanner(socket.getInputStream());
        printStream.println("login");
        String publicKey = "";
        if(scanner.hasNext()){
            publicKey = scanner.next();
            Id_passwd id_passwd = new Id_passwd();
            id_passwd.id=id;
            id_passwd.password=password;
            String id_passwdJSON = JSON.toJSONString(id_passwd); //生成JSON
            String enCodedId_PasswdJSON = RSA.encrypt(id_passwdJSON,publicKey); //加密
            printStream.println(enCodedId_PasswdJSON); //向服务器发送
        }
        if(scanner.hasNext()){
            String loginResJSON = scanner.next();
            Login_res login_res = JSON.parseObject(loginResJSON,Login_res.class);
            if(!RSA.checkSign(login_res.login,login_res.sign,publicKey))
                return false;
            if(login_res.login.startsWith("false"))
                return false;
        }
        return true;
    }
    public static String register1(String id, String password, PrintStream printStream,Scanner scanner) throws Exception { //返回的是问题的题面和公钥组成的json
        printStream.println("regist");
        String publicKey = "";
        if(scanner.hasNext()){
            publicKey = scanner.next();
            Id_passwd id_passwd = new Id_passwd();
            id_passwd.id=id;
            id_passwd.password=password;
            String id_passwdJSON = JSON.toJSONString(id_passwd); //生成JSON
            String enCodedId_PasswdJSON = RSA.encrypt(id_passwdJSON,publicKey); //加密
            printStream.println(enCodedId_PasswdJSON); //向服务器发送
        }
        if(scanner.hasNext()){
            String question = scanner.next();
            Question_PublicKey question_publicKey = new Question_PublicKey();
            question_publicKey.publicKey=publicKey;
            question_publicKey.question=question;
            return JSON.toJSONString(question_publicKey);
        }
        return "no question (>_<)";
    }
    public static boolean register2(String publicKey, String answer, PrintStream printStream,Scanner scanner) throws Exception { //发送问题答案并接受注册结果
        printStream.println(RSA.encrypt(answer,publicKey));
        if(scanner.hasNext()){
            String regist_res = scanner.next();
            if (regist_res.equals("OK"))
                return true;
        }
        return false;
    }
    public static String forget1(String id, PrintStream printStream,Scanner scanner) throws Exception { //返回的是问题的题面和公钥组成的json
        printStream.println("forget");
        String publicKey = "";
        if(scanner.hasNext()){
            publicKey = scanner.next();
            String enCodedId = RSA.encrypt(id,publicKey); //加密
            printStream.println(enCodedId); //向服务器发送
        }
        if(scanner.hasNext()){
            String question = scanner.next();
            Question_PublicKey question_publicKey = new Question_PublicKey();
            question_publicKey.publicKey=publicKey;
            question_publicKey.question=question;
            return JSON.toJSONString(question_publicKey);
        }
        return "no question (>_<)";
    }
    public static boolean forget2(String publicKey, String answer, PrintStream printStream,Scanner scanner) throws Exception { //发送问题答案并接受验证是否成功
        printStream.println(RSA.encrypt(answer,publicKey));
        if(scanner.hasNext()){
            String regist_res = scanner.next();
            if (regist_res.equals("OK"))
                return true;
        }
        return false;
    }
    public static void forget3(String publicKey, String newPassword, PrintStream printStream,Scanner scanner) throws Exception { //发送新密码
        printStream.println(RSA.encrypt(newPassword,publicKey));
    }
    public static int SelectInfected(String id) throws Exception { //查询id所在地区的阳性个数
        Socket socket = new Socket("103.46.128.53",48411);
        PrintStream printStream = new PrintStream(socket.getOutputStream());
        Scanner scanner = new Scanner(socket.getInputStream());
        printStream.println("select");
        String publicKey = "";
        if(scanner.hasNext()){
            publicKey = scanner.next();
            String enCodedId = RSA.encrypt(id,publicKey); //加密
            printStream.println(enCodedId); //向服务器发送
        }
        if(scanner.hasNext()){
            String Infecteds = scanner.next();
            return Integer.parseInt(Infecteds);
        }
        return -1;
    }
    public static String update1(PrintStream printStream,Scanner scanner){ //提交请求，得到公钥
        printStream.println("update");
        if(scanner.hasNext()){
            String publicKey = scanner.next();
            return publicKey;
        }
        return "";
    }
    public static boolean update2(String publicKey, String id, String name, int sex, String region, String birthday, String password, PrintStream printStream,Scanner scanner) throws Exception { //加密发送信息
        User_info user_info =new User_info();
        user_info.id=id;
        user_info.name=name;
        user_info.sex=sex;
        user_info.region=region;
        user_info.birthday=birthday;
        user_info.password=password;
        String user_infoJSON = JSON.toJSONString(user_info);
        printStream.println(RSA.encrypt(user_infoJSON,publicKey));
        if(scanner.hasNext()){
            String update_res = scanner.next();
            if(update_res.equals("OK"))
                return true;
        }
        return false;
    }
}
