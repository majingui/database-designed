import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQL {
    public static Connection SQLConnector() throws ClassNotFoundException, SQLException {
        Connection ConToSql;//jdbc驱动
        String driver="com.mysql.cj.jdbc.Driver";
        String url="jdbc:mysql://localhost:3306/db_expr4?&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        String user="root";
        String password="mima";
        Class.forName(driver);//注册JDBC驱动程序
        ConToSql = DriverManager.getConnection(url, user, password);//建立连接
        return ConToSql;
    }
}
