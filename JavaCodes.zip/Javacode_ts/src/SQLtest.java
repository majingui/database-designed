import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SQLtest {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Connection ConToSql=SQL.SQLConnector();
        ConToSql.setAutoCommit(true);
        String id = "yzx";
        String md5PassWord = "666";
        int result =1;
        String md5answer ="999";
        String sql="INSERT INTO managers (manager_id) VALUES ('"+id+"')"; //先插入users表
        PreparedStatement preparedStatement = ConToSql.prepareCall(sql); //执行查询结果并且返回结果集
        preparedStatement.executeUpdate();
        sql = "INSERT INTO manager_passwords (id,passwd,protection_question_id,protection_answer_hash) VALUES ('"+id+"','"+md5PassWord+"',"+result+",'"+md5answer+"')";
        preparedStatement = ConToSql.prepareCall(sql); //执行查询结果并且返回结果集
        preparedStatement.executeUpdate();


    }
}
