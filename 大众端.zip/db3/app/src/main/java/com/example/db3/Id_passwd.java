package com.example.db3;

public class Id_passwd {
    public String id;
    public String password;
}

