package com.example.db3;

public class Infecteds {
    public String Infecteds; //是一个将感染者列表所转换成的JSON
    public String sign; //对前者的签名
}
