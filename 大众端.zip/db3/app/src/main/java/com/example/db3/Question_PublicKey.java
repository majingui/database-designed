package com.example.db3;

public class Question_PublicKey {
    public String question;
    public String publicKey;
}
