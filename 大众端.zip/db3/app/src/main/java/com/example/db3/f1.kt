package com.example.db3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.widget.Button
import android.widget.EditText
import kotlin.concurrent.thread

class f1 : AppCompatActivity(),View.OnClickListener {
    var tof2=3
    var q_p1= "未获得问题"
    var pass = "1"
    val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 在这里可以进行UI操作
            when (msg.what) {
                tof2 -> {
                    //Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show()
                    val intent = Intent(getApplicationContext(), f2::class.java)
                    intent.putExtra("q_p",q_p1)
                    intent.putExtra("passward",pass)
                    startActivity(intent)//Intent是可以传递信息的
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_f1)
        var button61: Button = findViewById(R.id.button61)
        button61.setOnClickListener(this)

    }
    override fun onClick(v: View?) {
        //View表示视图的调用，
        //v便是那个视图
        var inputText = "您提交的信息为："
        when(v?.id){
            R.id.button61-> {
                thread {
                    var ID = findViewById<EditText>(R.id.editText61).text.toString()
                    var newpassd = findViewById<EditText>(R.id.editText62).text.toString()
                    (application as MySocket).initSocket()
                    var jsonf1 = PublicFunctions.forget1(ID,(application as MySocket).getPrintStream(),(application as MySocket).getScanner())
                    if (jsonf1!="no question (>_<)"){
                        //var q_p :Question_PublicKey = JSON.parseObject(jsonr1,Question_PublicKey::class.java)
                        q_p1 = jsonf1//把密码带到下一个界面
                        pass = newpassd
                        val msg = Message()
                        msg.what = tof2
                        handler.sendMessage(msg)
                    }
                }
//                val intent = Intent(this, f2::class.java)
//                startActivity(intent)
            }

        }
    }
}