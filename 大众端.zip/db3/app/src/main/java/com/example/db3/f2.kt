package com.example.db3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.alibaba.fastjson.JSON
import kotlin.concurrent.thread

class f2 : AppCompatActivity(),View.OnClickListener {
    var passwd = "123456"
    var publicKey = "hhh"
    var torlo = 7
    val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 在这里可以进行UI操作
            when (msg.what) {
                torlo -> {
                    System.out.println("111111k")
                    //Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show()
                    val intent = Intent(getApplicationContext(), login_activity::class.java)
                    //intent.putExtra("q_p",q_p)
                    startActivity(intent)//Intent是可以传递信息的
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_f2)
        passwd = intent.getStringExtra("passward").toString()

        var tmp = intent.getStringExtra("q_p")
        var a = JSON.parseObject(tmp,Question_PublicKey::class.java)

        publicKey = a.publicKey
        findViewById<TextView>(R.id.textView72).text = a.question
        var button71: Button = findViewById(R.id.button71)
        button71.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        //View表示视图的调用，
        //v便是那个视图
        var inputText = "您提交的信息为："
        if(true){
            when(v?.id){
                R.id.button71-> {
                    var ans = findViewById<EditText>(R.id.editText71).text.toString()//全部用串
                    thread{
                        var res = PublicFunctions.forget2(publicKey,ans,(application as MySocket).getPrintStream(),(application as MySocket).getScanner())
                        if (res==true){
                            PublicFunctions.forget3(publicKey,passwd,(application as MySocket).getPrintStream(),(application as MySocket).getScanner())
                            val msg = Message()
                            msg.what = torlo
                            handler.sendMessage(msg)
                        }
                        else{
                            //Toast.makeText(getApplicationContext(),"回答错误",Toast.LENGTH_SHORT).show()
                        }
                    }
//                    val intent = Intent(this, login_activity::class.java)
//                    startActivity(intent)
                }
            }
        }
        else{
            //Toast.makeText(this, "回答错误，请重试", Toast.LENGTH_SHORT).show()
        }

    }
}