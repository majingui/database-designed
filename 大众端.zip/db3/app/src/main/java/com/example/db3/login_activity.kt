package com.example.db3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlin.concurrent.thread

class login_activity : AppCompatActivity(),View.OnClickListener {
    val canLogin = 1
    var myID = "hw"
    var passwd = "123456"
    val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 在这里可以进行UI操作
            when (msg.what) {
                canLogin -> {
                    //Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show()
                    val intent = Intent(getApplicationContext(), MainActivity::class.java)
                    intent.putExtra("ID",myID)
                    intent.putExtra("passward",passwd)
                    startActivity(intent)//Intent是可以传递信息的
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        var button31: Button = findViewById(R.id.button31)
        button31.setOnClickListener(this)
        var button32: Button = findViewById(R.id.button32)
        button32.setOnClickListener(this)
        var button33: Button = findViewById(R.id.button33)
        button33.setOnClickListener(this)

    }
    override fun onClick(v: View?) {
        //View表示视图的调用，
        //v便是那个视图
        var inputText = "您提交的信息为："
        when(v?.id){
            R.id.button31-> {
                var inputID = findViewById<EditText>(R.id.editText31).text.toString()
                this.myID = inputID
                var passward = findViewById<EditText>(R.id.editText32).text.toString()
                this.passwd = passward
                thread {
                    //System.out.println("进来啦${inputID}")线程进去成功
                    var result = PublicFunctions.login(inputID,passward)
                    if (result==true){//handler更新成功
                        val msg = Message()
                        msg.what = canLogin
                        handler.sendMessage(msg) // 将Message对象发送出去
                    }
                }

            }
            R.id.button32-> {
                val intent = Intent(this, r1::class.java)
                startActivity(intent)
            }
            R.id.button33-> {
                val intent = Intent(this, f1::class.java)
                startActivity(intent)
            }
        }
    }
}