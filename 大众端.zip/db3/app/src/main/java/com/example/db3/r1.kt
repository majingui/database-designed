package com.example.db3


import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.system.Os.socket
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.alibaba.fastjson.JSON
import java.io.PrintStream
import java.net.Socket
import java.util.Scanner
import java.util.*
import kotlin.concurrent.thread


class r1 : AppCompatActivity(),View.OnClickListener {
    val tor2 = 2
    var q_p = "未获取问题"
    val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 在这里可以进行UI操作
            when (msg.what) {
                tor2 -> {
                    //Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show()
                    val intent = Intent(getApplicationContext(), r2::class.java)
                    intent.putExtra("q_p",q_p)
                    startActivity(intent)//Intent是可以传递信息的
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_r1)
        var button41: Button = findViewById(R.id.button41)
        button41.setOnClickListener(this)

    }
    override fun onClick(v: View?) {

        var inputText = "您提交的信息为："
        when(v?.id){
            R.id.button41-> {
                var inputID = findViewById<EditText> (R.id.editText41).text.toString()
                var passward = findViewById<EditText>(R.id.editText42).text.toString()
                thread{
//            var socketr1 = Socket("103.46.128.53",48411)
                    //下面是不是这样用的？？？？？
                    System.out.println("1111111")
                    (application as MySocket).initSocket()//目前连不上服务器
                    System.out.println("222222221")
                    var scannerr1 = (application as MySocket).getScanner()//设置全局
                    var printStreamr1 = (application as MySocket).getPrintStream()
                    var jsonr1 = PublicFunctions.register1(inputID,passward,printStreamr1,scannerr1)
                    if (jsonr1!="no question (>_<)"){
                        //var q_p :Question_PublicKey = JSON.parseObject(jsonr1,Question_PublicKey::class.java)
                        q_p = jsonr1
                        val msg = Message()
                        msg.what = tor2
                        handler.sendMessage(msg)
                    }
                }


//                val intent = Intent(this, r2::class.java)
//                startActivity(intent)
            }

        }
    }
}