package com.example.db3


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.alibaba.fastjson.JSON
import kotlin.concurrent.thread

class r2 : AppCompatActivity(), View.OnClickListener {
    var publicKey = "hhh"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_r2)
        var q_p = intent.getStringExtra("q_p")
        var q_pObj :Question_PublicKey = JSON.parseObject(q_p,Question_PublicKey::class.java)
        var text52 = findViewById<TextView>(R.id.textView52)//要给他足够信息找
        text52.text = q_pObj.question
        publicKey = q_pObj.publicKey
        var button51: Button = findViewById(R.id.button51)
        button51.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        //View表示视图的调用，
        //v便是那个视图
        var inputText = "您提交的信息为："
        when(v?.id){
            R.id.button51-> {
                var ans = findViewById<EditText>(R.id.editText51).text.toString()//全部用串
                thread{
                    var res = PublicFunctions.register2(publicKey,ans,(application as MySocket).getPrintStream(),(application as MySocket).getScanner())
                    //这里要把socket断掉
                    (application as MySocket).socket.close()
                    if (res==true){
                        val intent = Intent(this, login_activity::class.java)
                        startActivity(intent)
                    }
                    else{
                        //Toast.makeText(getApplicationContext(),"回答错误",Toast.LENGTH_SHORT).show()
                    }
                }

            }

        }
    }
}