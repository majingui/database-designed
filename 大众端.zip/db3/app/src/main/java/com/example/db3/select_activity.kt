package com.example.db3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlin.concurrent.thread

class select_activity : AppCompatActivity(),View.OnClickListener {
    var myID2:String = "hw"//全局，和f和r不一样
    var select1 = 4
    var num = 0

    val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 在这里可以进行UI操作
            when (msg.what) {
                select1 -> {
                    //Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show()
                    findViewById<ProgressBar>(R.id.progressBar1).visibility = View.GONE
                    AlertDialog.Builder(this@select_activity).apply {//content是运行上下文的意思
                        setTitle("查询结果")
                        setMessage("当前查询到，您所在的区域的阳性患者有${num}人")
                        setCancelable(true)//可用back键退出
                        setPositiveButton("知道了") { dialog, which ->
                        }//这里可用根据不同的按键执行不同的功能。在which后面
                        setNegativeButton("我不相信！！！") { dialog, which ->
                        }
                        show()
                    }
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select)
        myID2 = intent.getStringExtra("ID")!!//会抛出空异常
        val button2: Button = findViewById(R.id.button2)
        button2.setOnClickListener(this)//如果这个实现了会覆盖下面的onclick
        val button3: Button = findViewById(R.id.button3)
        findViewById<ProgressBar>(R.id.progressBar1).visibility = View.GONE
        button3.setOnClickListener{
            //Toast.makeText(this,"正在查询当地疫情状况", Toast.LENGTH_SHORT).show()
            finish()//结束当前activity
            //执行查询功能
        }
    }
    override fun onClick(v: View?) {//这种监听能够监听到多个按钮并做出反应
        var progressBar1:ProgressBar = findViewById(R.id.progressBar1)
        when (v?.id) {//点一次就转 点两次就不转，但是好像有点问题
            R.id.button2 -> {
                if (progressBar1.visibility != View.VISIBLE) {
                    progressBar1.visibility = View.VISIBLE
                }//转起来

                Toast.makeText(this,"正在查询当地疫情状况", Toast.LENGTH_SHORT).show()
                thread {
                    num = PublicFunctions.SelectInfected(myID2)//不知道ID
                    val msg = Message()
                    msg.what = select1
                    handler.sendMessage(msg)
                }


            }

        }
    }
}