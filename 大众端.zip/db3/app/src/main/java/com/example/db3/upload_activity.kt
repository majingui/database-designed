package com.example.db3


import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class upload_activity : AppCompatActivity(),View.OnClickListener{
    var myID2 = "hw"
    var passwd2 = "123456"
    var publicKey1 = "111"
    var uploadOK = 5

    val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 在这里可以进行UI操作
            when (msg.what) {
                uploadOK -> {
                    //Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show()
                    Toast.makeText(getApplicationContext(),"上传成功",Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload)
        myID2 = intent.getStringExtra("ID").toString()
        passwd2 = intent.getStringExtra("passward").toString()
        val button4: Button = findViewById(R.id.button4)
        button4.setOnClickListener(this)//此处不展开逻辑，因为下面有自己定义的一个监听
        val button5: Button = findViewById(R.id.button5)
        button5.setOnClickListener{
            //Toast.makeText(this,"正在查询当地疫情状况", Toast.LENGTH_SHORT).show()
            finish()//结束当前activity
            //执行查询功能
        }
    }


    override fun onClick(v: View?) {
        //View表示视图的调用，
        //v便是那个视图
        var inputText = "您提交的信息为："
        when(v?.id){
            R.id.button4-> {
                var input4= findViewById<EditText>(R.id.editText4).text.toString()
//                inputText=inputText+input4.text.toString()
                var input5 = findViewById<EditText>(R.id.editText5).text.toString()
//                inputText=inputText+input5.text.toString()
                var input9 = findViewById<EditText>(R.id.editText9).text.toString()//输入要求是int
//                inputText=inputText+input9.text.toString()
                var input10 = findViewById<EditText>(R.id.editText10).text.toString()
//                inputText=inputText+input10.text.toString()
                var input14= findViewById<EditText>(R.id.editText14).text.toString()
//                inputText=inputText+input14.text.toString()
                //edittext文编编辑的getText方法获取输入框的类容，toString()方法转成字符
                thread {
                    (application as MySocket).initSocket()
                    publicKey1 = PublicFunctions.update1((application as MySocket).getPrintStream(),(application as MySocket).getScanner())
                    var res = PublicFunctions.update2(publicKey1,input4,input5,input9.toInt(),input10,input14,passwd2,(application as MySocket).getPrintStream(),(application as MySocket).getScanner())
                    if(res == true){
                        val msg = Message()
                        msg.what = uploadOK
                        handler.sendMessage(msg)
                    }
                }

                //显示字符
            }
        }
    }
}