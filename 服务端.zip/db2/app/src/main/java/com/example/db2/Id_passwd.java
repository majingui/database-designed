package com.example.db2;

public class Id_passwd {
    public String id;
    public String password;
}

