package com.example.db2;

public class Login_res {
    public String login; //格式为"true&时间戳"或者"false&时间戳"
    public String sign; //对前者的签名
}
