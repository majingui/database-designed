package com.example.db2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    var myID1:String = "hw"
    var mypasswd1 = "123456"
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        myID1 = intent.getStringExtra("ID").toString()
        mypasswd1 = intent.getStringExtra("passward").toString()
//        val data = listOf(
//            "Apple", "Banana", "Orange", "Watermelon",
//            "Pear", "Grape", "Pineapple", "Strawberry", "Cherry", "Mango",
//            "Apple", "Banana", "Orange", "Watermelon", "Pear", "Grape",
//            "Pineapple", "Strawberry", "Cherry", "Mango"
//        )
//        //View没有绑定总是出现这种问题
//        var mylist :ListView = findViewById(R.id.listView)
//        val adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,data)
//        mylist.adapter = adapter
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {//下面是两个已经注册好的菜单，点击哪一个就能执行对应的逻辑
            R.id.add_item -> {
                val intent = Intent(this, select_activity::class.java)
                intent.putExtra("ID",myID1)
                intent.putExtra("passward",mypasswd1)
                startActivity(intent)
            }
            R.id.remove_item -> {
                val intent = Intent(this, upload_activity::class.java)
                intent.putExtra("ID",myID1)
                intent.putExtra("passward",mypasswd1)
                startActivity(intent)
            }

        }
        return true
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true//super.onCreateOptionsMenu(menu)
    }
}