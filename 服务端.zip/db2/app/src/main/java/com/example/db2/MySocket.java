package com.example.db2;

import android.app.Application;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

public class MySocket extends Application {
    Socket socket = null;
    PrintStream printStream = null;
    Scanner scanner = null;
    public void initSocket() throws IOException {
        System.out.println("33333333");//这里执行了
        this.socket = new Socket("124.221.73.207",8879);
        System.out.println("33333333");//这里没有执行
        this.printStream = new PrintStream(socket.getOutputStream());
        this.scanner = new Scanner(socket.getInputStream());

    }
    public void initSocket1() throws IOException {
        this.printStream = new PrintStream(socket.getOutputStream());
        this.scanner = new Scanner(socket.getInputStream());

    }

    public Socket getSocket(){
        return socket;
    }
    //    public void setSocket(Socket socket){
//        this.socket = socket;
//    }
    public Scanner getScanner(){
        return this.scanner;
    }
    public PrintStream getPrintStream(){
        return this.printStream;
    }
}
