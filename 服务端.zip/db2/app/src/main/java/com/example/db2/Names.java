package com.example.db2;


import java.util.ArrayList;
import java.util.List;

public class Names {
    public List<String> names = new ArrayList<String>();
}