package com.example.db2;

public class Question_PublicKey {
    public String question;
    public String publicKey;
}
