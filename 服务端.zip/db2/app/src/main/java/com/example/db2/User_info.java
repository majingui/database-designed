package com.example.db2;

public class User_info { //存储用户的基本信息
    public String id;
    public String name;
    public int sex;
    public String region;
    public String birthday;
    public String password;
}
