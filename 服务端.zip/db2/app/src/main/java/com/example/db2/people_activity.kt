package com.example.db2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.TypeReference
import java.lang.Exception
import kotlin.concurrent.thread

class people_activity : AppCompatActivity(),View.OnClickListener {
    var infojson = "没查到"
    var info  =6
    val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 在这里可以进行UI操作
            when (msg.what) {
                info -> {

                    //Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show()
                    var infoObj = JSON.parseObject(infojson,Infected_info::class.java)
                    var k = "性别未知"
                    if(infoObj.sex.toInt()==1){
                        k = "男"
                    }
                    else{
                        k = "女"
                    }
                    var output ="姓名:"+infoObj.name+ "\n年龄段:"+infoObj.age+
                            "+\n性别:"+k
                    //Toast.makeText(getApplicationContext(),"test",Toast.LENGTH_SHORT)
                    System.out.println("11111111sss")
                    runOnUiThread{
                        try {
                            AlertDialog.Builder(this@people_activity).apply {//content是运行上下文的意思
                                //System.out.println("11111111sss")
                                setTitle("${infoObj.name}的信息如下")
                                //System.out.println("11111111sss")
                                setMessage(
                                    output
                                )
                                //System.out.println("11111111sss")
                                setCancelable(true)//可用back键退出
                                setPositiveButton("知道了") { dialog, which ->
                                }//这里可用根据不同的按键执行不同的功能。在which后面
                                setNegativeButton("我不相信！！！") { dialog, which ->
                                }
                                show()
                            }
                        }catch (e:Exception){
                            System.out.println(e.toString())
                        }

                    }

                    System.out.println("11111111sss")
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_people)
        System.out.println("1111111o")
        var wait:ProgressBar = findViewById(R.id.progressBar1)
        wait.visibility = View.VISIBLE
        var tmp = intent.getStringExtra("list")
        System.out.println(tmp)
        var namelist:Names? = null
        try {
            namelist= JSON.parseObject(tmp,Names::class.java)
            System.out.println(tmp)
        }catch (e:Exception){
            System.out.println("sss")
        }
        var lists = namelist!!.names
        System.out.println(lists)
        var list1:ListView = findViewById(R.id.listView11)
        val adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,lists)
        list1.adapter = adapter
        wait.visibility = View.GONE
        //下面回调直接写这里，也可以this然后用下面
        list1.setOnItemClickListener { parent, view, position, id ->//这里只有position下标有用
            //这里应该要：点击时开始搜索 结束时再弹窗
            var who = namelist.names[position]
            //var who  = "jjj"
            thread {
                //(application as MySocket).initSocket()
                infojson = AdminFunctions.select2(who,(application as MySocket).getPrintStream(),(application as MySocket).getScanner())
                System.out.println("111111"+infojson)
                val msg = Message()
                msg.what = info
                handler.sendMessage(msg)
            }

        }
//        var button11: Button = findViewById(R.id.button11)
//        button11.setOnClickListener(this)
//        var button12: Button = findViewById(R.id.button12)
//        button12.setOnClickListener(this)
//        var button13: Button = findViewById(R.id.button13)
//        button13.setOnClickListener(this)
//        var button14: Button = findViewById(R.id.button14)
//        button14.setOnClickListener(this)
//        var button15: Button = findViewById(R.id.button15)
//        button15.setOnClickListener(this)
//        var button16: Button = findViewById(R.id.button16)
//        button16.setOnClickListener(this)//要先注册按钮才能回调
//        var button17: Button = findViewById(R.id.button17)
//        button17.setOnClickListener(this)
//        var button18: Button = findViewById(R.id.button18)
//        button18.setOnClickListener(this)//要先注册按钮才能回调
    }
//    override fun onClick(v: View?) {//这种监听能够监听到多个按钮并做出反应
//        AlertDialog.Builder(this).apply {//content是运行上下文的意思
//            setTitle("确诊者详细情况")
//            setMessage("当前查询到该确诊者的信息如下(服务器发来的信息)")
//            setCancelable(true)//可用back键退出
//            setPositiveButton("知道了") { dialog, which ->
//            }//这里可用根据不同的按键执行不同的功能。在which后面
//            setNegativeButton("我不相信！！！") { dialog, which ->
//            }
//            show()
//        }
//
//    }
    override fun onClick(v: View?) {
//    when (v?.id) {
//        R.id.button -> {
//            if (progressBar.visibility == View.VISIBLE) {
//                progressBar.visibility = View.GONE
//            } else {
//                progressBar.visibility = View.VISIBLE
//            }
//        }
//    }
    }
}