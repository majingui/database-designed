package com.example.db2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlin.concurrent.thread

class select_activity : AppCompatActivity(),View.OnClickListener{
    var myID2:String = "hw"//全局，和f和r不一样
    var select1 = 4
    var region = "hhh"
    var infectjson = "111"
    val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 在这里可以进行UI操作
            when (msg.what) {
                select1 -> {
                    System.out.println("1111111p")
                    val intent = Intent(getApplicationContext(), people_activity::class.java)
                    System.out.println("1111111s")
                    intent.putExtra("list",infectjson)
                    System.out.println("1111111d")
                    startActivity(intent)

                    //Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show()
//                    findViewById<ProgressBar>(R.id.progressBar1).visibility = View.GONE
//                    AlertDialog.Builder(getApplicationContext()).apply {//content是运行上下文的意思
//                        setTitle("查询结果")
//                        setMessage("当前查询到，您所在的区域没有疫情")
//                        setCancelable(true)//可用back键退出
//                        setPositiveButton("知道了") { dialog, which ->
//                        }//这里可用根据不同的按键执行不同的功能。在which后面
//                        setNegativeButton("我不相信！！！") { dialog, which ->
//                        }
//                        show()
                  //  }
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select)
        var button1:Button = findViewById(R.id.button1)
        button1.setOnClickListener(this)
        var button2:Button = findViewById(R.id.button2)
        button2.setOnClickListener(this)
        var button3:Button = findViewById(R.id.button3)
        button3.setOnClickListener(this)
        var button4:Button = findViewById(R.id.button4)
        button4.setOnClickListener(this)
        var button5:Button = findViewById(R.id.button5)
        button5.setOnClickListener(this)
        var button6:Button = findViewById(R.id.button6)
        button6.setOnClickListener(this)//要先注册按钮才能回调



    }
    override fun onClick(v: View?) {//这种监听能够监听到多个按钮并做出反应
        when(v?.id){
            R.id.button1->{
               this.region = findViewById<Button>(R.id.button1).text.toString()
                System.out.println("1111111r")
            }
            R.id.button2->{
                this.region = findViewById<Button>(R.id.button2).text.toString()
            }
            R.id.button3->{
                this.region = findViewById<Button>(R.id.button3).text.toString()
            }
            R.id.button4->{
                this.region = findViewById<Button>(R.id.button4).text.toString()
            }
            R.id.button5->{
                this.region = findViewById<Button>(R.id.button5).text.toString()
            }
            R.id.button6->{
                this.region = findViewById<Button>(R.id.button6).text.toString()
            }
        }
        thread {
            System.out.println("1111111t")
            (application as MySocket).initSocket()
            System.out.println("1111111y")
            this.infectjson = AdminFunctions.select1(this.region,(application as MySocket).getPrintStream(),(application as MySocket).getScanner())
            val msg = Message()
            msg.what = select1
            handler.sendMessage(msg)

        }



    }
}