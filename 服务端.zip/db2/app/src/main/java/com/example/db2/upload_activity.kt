package com.example.db2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlin.concurrent.thread

class upload_activity : AppCompatActivity(),View.OnClickListener {
    var myID2 = "hw"
    var passwd2 = "123456"
    var publicKey1 = "111"
    var uploadOK = 5
    val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            // 在这里可以进行UI操作
            when (msg.what) {
                uploadOK -> {
                    //Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show()
                    Toast.makeText(getApplicationContext(),"上传成功",Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload)
        myID2 = intent.getStringExtra("ID").toString()
        passwd2 = intent.getStringExtra("passward").toString()
        var button21: Button = findViewById(R.id.button21)
        button21.setOnClickListener(this)
    }
    override fun onClick(v: View?) {//这种监听能够监听到多个按钮并做出反应
        when(v?.id){
            R.id.button21-> {
                var inputText = ""
                var input1= findViewById<EditText>(R.id.editText1).text.toString()
                //inputText=inputText+input1
                var input2= findViewById<EditText>(R.id.editText2).text.toString()
                thread {
                    AdminFunctions.update(input1)
                        val msg = Message()
                        msg.what = uploadOK
                        handler.sendMessage(msg)
                }
            //inputText=inputText+input2.text.toString()
                //edittext文编编辑的getText方法获取输入框的类容，toString()方法转成字符
                //Toast.makeText(this,inputText, Toast.LENGTH_SHORT).show()
                //显示字符
            }
        }

    }
}